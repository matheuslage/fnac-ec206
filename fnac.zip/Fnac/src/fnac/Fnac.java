package fnac;

import fnac.view.TelaPrincipal;

public class Fnac {

    public static void main(String[] args) {
        TelaPrincipal telaPrincipal = new TelaPrincipal();
        telaPrincipal.setVisible(true);
    }
   
}